<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use Illuminate\Http\Request;

class FaqApiController extends Controller
{
    // GET /api/faqs
    public function index(Request $request)
    {
        $query = Faq::active()->ordered();

        if ($request->filled('search')) {
            $query->where('question', 'like', '%' . $request->search . '%');
        }

        return response()->json([
            'success' => true,
            'data' => $query->get(['id', 'question', 'answer']),
        ]);
    }
}